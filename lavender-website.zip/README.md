# 🌸 Lavender Website Project

Project website sederhana bertema bunga lavender.

## Fitur
- Desain ungu lavender
- Galeri gambar
- Tombol interaktif dengan JavaScript

## Cara Menjalankan
1. Download project
2. Buka file index.html di browser

## Cocok Untuk
- Portfolio GitHub
- Belajar HTML, CSS, JavaScript dasar
