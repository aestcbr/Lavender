function showMessage() {
    alert("Lavender memberikan ketenangan dan keindahan 🌸");
}
